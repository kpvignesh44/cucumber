package com.excel;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_Reg_Log {
	public String username(int i) throws IOException
	{
		
		FileInputStream file= new FileInputStream("C:\\Users\\HP\\Documents\\training_data.xlsx");
		XSSFWorkbook workbook =new XSSFWorkbook(file);
		XSSFSheet sheet= workbook.getSheet("testdata");
		
			
			XSSFRow row= sheet.getRow(i);
			XSSFCell cell= row.getCell(0);
			 cell.setCellType(CellType.STRING);
			String un= cell.getStringCellValue();
			
			return un;
	}	
//	public int coun() throws IOException
//	{
//		FileInputStream file= new FileInputStream("C:\\Users\\HP\\Documents\\training_data.xlsx");
//		XSSFWorkbook workbook =new XSSFWorkbook(file);
//		XSSFSheet sheet= workbook.getSheet("testdata");
//		
//		int count= sheet.getLastRowNum();
//		System.out.println(count);
//		return count;
//	}
	//To read and get password
	public String password(int i) throws IOException
	{
		
		FileInputStream file= new FileInputStream("C:\\Users\\HP\\Documents\\training_data.xlsx");
		XSSFWorkbook workbook =new XSSFWorkbook(file);
		XSSFSheet sheet= workbook.getSheet("testdata");
		int count= sheet.getLastRowNum();
		System.out.println(count);
			
			XSSFRow row= sheet.getRow(i);
			XSSFCell cell1= row.getCell(1);
			 cell1.setCellType(CellType.STRING);
			String pwd= cell1.getStringCellValue();
			
			return pwd;
	}
}
