package com.steps;

import com.pages.Register_and_Login;
import com.pages.Shop;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Training_steps {
Register_and_Login reglog=new Register_and_Login();
Shop s=new Shop();

//Scenario:To check if the user is able to register with valid details

	@Given("^Launch the chrome browser in system$")
	public void  launching_Browser()
	{
	reglog.Launch_chrome();
	}
	@Then("^open the Practise automation website$")
	public void opening_website()
	{
	reglog.Open_Website();
	}
	@Then("^Enter the Email and password$")
	public void registering()
	{
	reglog.register();
	}
	@And("^Click the Register button$")
	public void loging_into_website() throws Exception
	{
	reglog.click_Reg_Button();
	}
	
//	Scenario: To check if the user is able to Login with valid details	
	@Then("^Enter the Email and password in Login$")
	public void Logging() throws Exception
	{
		reglog.login_into_website();
	}
	@And("^Click Login Button$")
	public void clicking_login() throws Exception
	{
		reglog.click_login();
	}
	
//	Scenario: To check if the user is able to filter the price using slider
	@Then("^click_Shop_icon and Filter price using Slider$")
	public void filter() throws InterruptedException
	{Thread .sleep(5000);
		reglog.slider();
	}
	
//	Scenario: To check if the user is able to add the books in the basket on the filtered price
	
	@And("^Add the books to the basket$")
	public void books_in_selected_filter()
	{
		reglog.basket();
	}
	
	@Then("^View the cart$")
	public void viewing_cart()
	{
		reglog.viewing_cart();
	}
	
//	To check if the user is able to buy books from android category
	
	@Then("^Click Shop icon")
	public void clicking_the_shop_icon() throws InterruptedException
	{
		reglog.shop_icon();
	}
	
	@And("^Click android and buy the book$")
	public void Buying_android_book()
	{
		reglog.android_book();
		
	}
	
	
//	Scenario: To check if the user is able to buy books from HTML category
	

	
	@And("^Click HTML and buy the book$")
	public void Buying_HTML_book() throws InterruptedException
	{
		reglog.HTML_book();
		
	}
//	Scenario: To check if the user is able to buy books from javascipt category
	

	@And("^Click JavaScript and buy the book$")
	public void Buying_JS_book() throws InterruptedException
	{
		reglog.javascript_book();
		
	}
	
	
//	Scenario: To check if the user is able to buy books from Selenium category	

	@And("^Click Selenium and buy the book$")
	public void Buying_Selenium_book() throws InterruptedException
	{
		reglog.Selenium_book();
		
	}
	
	
//	Scenario: To check if the user is able to able to filter the prices from low to high
	@Then("^In Dropdown select the prices from low to high$")
	public void low_to_high()
	{
		reglog.Price_low_to_high();
	}
	
	
//	Scenario: To check if the user is able to able to filter the prices from high to low
	@Then("^In Dropdown select the prices from high to low$")
	public void high_to_low() throws InterruptedException
	{
		reglog.Price_high_to_low();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

