package com.runner;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/main/resources/Feature/training.feature",
		plugin = {"pretty", "html:reports/cucumber-html-report"},
//        tags = {"@TC_10_Filtering_The_Price_from_high_to_low"},
		glue = {"com.steps"},
		monochrome = true
		)
public class Training_runner {

}
