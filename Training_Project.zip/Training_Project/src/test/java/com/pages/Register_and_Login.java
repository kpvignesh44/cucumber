package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.excel.Excel_Reg_Log;

import junit.framework.Assert;





public class Register_and_Login {
	WebDriver driver;


	By myaccount = By.xpath("//*[@id=\"menu-item-50\"]/a");
	By regemail = By.id("reg_email");
	By regpass = By.id("reg_password");
	By registerbutton = By.xpath("//*[@id=\"customer_login\"]/div[2]/form/p[3]/input[3]");
	By logemail = By.id("username");
	By logpass = By.id("password");
	By loginbutton = By.xpath("//*[@id=\"customer_login\"]/div[1]/form/p[3]/input[3]");

	
	public void Launch_chrome() 
	{ 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Downloads\\chromedriver_win32\\chromedriver.exe");			
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	

	public void Open_Website() 
	{
		driver.get("http://practice.automationtesting.in/my-account/");
		System.out.println(driver.getTitle());
	}
	
	
	public void register()
	{
		driver.findElement(regemail).sendKeys("kpvickey44@pec.edu");
		driver.findElement(regpass).sendKeys("8760575400@#");
		
	}
	public void click_Reg_Button() throws InterruptedException
	{
		driver.findElement(registerbutton).click();
		Thread.sleep(5000);
	}
	public void login_into_website() throws Exception
	{
		Excel_Reg_Log ed = new Excel_Reg_Log();

   
			
				driver.findElement(logemail).sendKeys(ed.username(1));
				driver.findElement(logpass).sendKeys(ed.password(1));
				
				
				
			
   
	}
	public void click_login()
	{
		driver.findElement(loginbutton).click();
	}

	public void slider() throws InterruptedException
	{
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"menu-item-40\"]")).click();
		Thread.sleep(5000);
		WebElement Slider = driver.findElement(By.xpath("//*[@id=\"woocommerce_price_filter-2\"]/form/div/div[1]/div"));

		Actions builder = new Actions(driver);

		org.openqa.selenium.interactions.Action dragAndDrop =

		builder.clickAndHold(Slider).moveByOffset(40,0).release().build();

		dragAndDrop.perform(); 
		driver.findElement(By.xpath("//*[@id=\"woocommerce_price_filter-2\"]/form/div/div[2]/button")).click();
	}
	
	
	public void basket()
	{
		driver.findElement(By.xpath("//*[@id=\"content\"]/ul/li[2]/a[2]")).click();
		
	}
	
	public void viewing_cart()
	{
		driver.findElement(By.xpath("  //*[@id=\"wpmenucartli\"]/a/span[1]")).click();
	}
	public void shop_icon() throws InterruptedException
	{

		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"menu-item-40\"]")).click();
	}
	
	public void android_book()
	{
		driver.findElement(By.xpath("//*[@id=\"woocommerce_product_categories-2\"]/ul/li[1]/a")).click();
Assert.fail();
	}
	
	
public void HTML_book() throws InterruptedException
{Thread.sleep(5000);
	driver.findElement(By.xpath("//*[@id=\"woocommerce_product_categories-2\"]/ul/li[2]/a")).click();
	driver.findElement(By.xpath("//*[@id=\"content\"]/ul/li[1]/a[2]")).click();
}
	
	public void javascript_book() throws InterruptedException
	{Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"woocommerce_product_categories-2\"]/ul/li[3]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/ul/li[3]/a[2]")).click();
	}

	public void Selenium_book() throws InterruptedException
	{Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"woocommerce_product_categories-2\"]/ul/li[4]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"content\"]/ul/li/a[2]")).click();
	}
	public void Price_low_to_high()
	{driver.findElement(By.xpath("//*[@id=\"content\"]/form")).click();
		Select dropdown = new Select(driver.findElement(By.name("orderby")));
		dropdown.selectByIndex(4);
	}
	public void Price_high_to_low() throws InterruptedException
	{Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"content\"]/form")).click();
		Select dropdown = new Select(driver.findElement(By.name("orderby")));
		dropdown.selectByIndex(5);
	}
}
