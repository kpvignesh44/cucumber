$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/Feature/training.feature");
formatter.feature({
  "line": 2,
  "name": "Testing the practise automation website",
  "description": "",
  "id": "testing-the-practise-automation-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Practice_Automation"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "To check if the user is able to register with valid details",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-register-with-valid-details",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@TC-01_Register"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Enter the Email and password",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Click the Register button",
  "keyword": "And "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 4572932801,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 5287527592,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.registering()"
});
formatter.result({
  "duration": 509788033,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.loging_into_website()"
});
formatter.result({
  "duration": 5151731700,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "To check if the user is able to login with valid details",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-login-with-valid-details",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 13,
      "name": "@TC-02_Login_Functionlity"
    }
  ]
});
formatter.step({
  "line": 15,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 3738856639,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 3514165708,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 1823776505,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 2082976834,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "To check if the user is able to filter the price using slider",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-filter-the-price-using-slider",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 20,
      "name": "@TC-03_Filter_Functionality"
    }
  ]
});
formatter.step({
  "line": 22,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "click_Shop_icon and Filter price using Slider",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 3942125132,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 4053596497,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 857686682,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 2011745036,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.filter()"
});
formatter.result({
  "duration": 18602497396,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "To check if the user is able to add the books in the basket on the filtered price",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-add-the-books-in-the-basket-on-the-filtered-price",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 28,
      "name": "@TC_04_Filtering_And_adding_to_Basket"
    }
  ]
});
formatter.step({
  "line": 30,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "Click Shop icon and Filter price using Slider",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Add the books to the basket",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "View the cart",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 3971921185,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 4336305777,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 363986244,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 3011112966,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_the_shop_icon()"
});
formatter.result({
  "duration": 6415648393,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.books_in_selected_filter()"
});
formatter.result({
  "duration": 1883209273,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.viewing_cart()"
});
formatter.result({
  "duration": 2110747543,
  "status": "passed"
});
formatter.scenario({
  "line": 41,
  "name": "To check if the user is able to buy books from android category",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-buy-books-from-android-category",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 40,
      "name": "@TC_05_Adding_books_from_android_Category"
    }
  ]
});
formatter.step({
  "line": 42,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 44,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 45,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 46,
  "name": "Click Shop icon",
  "keyword": "Then "
});
formatter.step({
  "line": 47,
  "name": "Click android and buy the book",
  "keyword": "And "
});
formatter.step({
  "line": 48,
  "name": "View the cart",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 3689884755,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 4012983879,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 668325254,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 1960274320,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_the_shop_icon()"
});
formatter.result({
  "duration": 7133664447,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Buying_android_book()"
});
formatter.result({
  "duration": 1777079924,
  "error_message": "junit.framework.AssertionFailedError\r\n\tat junit.framework.Assert.fail(Assert.java:55)\r\n\tat junit.framework.Assert.fail(Assert.java:64)\r\n\tat com.pages.Register_and_Login.android_book(Register_and_Login.java:114)\r\n\tat com.steps.Training_steps.Buying_android_book(Training_steps.java:81)\r\n\tat ✽.And Click android and buy the book(src/main/resources/Feature/training.feature:47)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "Training_steps.viewing_cart()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 53,
  "name": "To check if the user is able to buy books from HTML category",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-buy-books-from-html-category",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 52,
      "name": "@TC_06_Adding_books_from_HTML_Category"
    }
  ]
});
formatter.step({
  "line": 54,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 55,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 56,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 57,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 58,
  "name": "Click Shop icon",
  "keyword": "Then "
});
formatter.step({
  "line": 59,
  "name": "Click HTML and buy the book",
  "keyword": "And "
});
formatter.step({
  "line": 60,
  "name": "View the cart",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 3634196458,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 3449296529,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 708684892,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 2381880565,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_the_shop_icon()"
});
formatter.result({
  "duration": 7396248279,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Buying_HTML_book()"
});
formatter.result({
  "duration": 6923671991,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.viewing_cart()"
});
formatter.result({
  "duration": 1320992223,
  "status": "passed"
});
formatter.scenario({
  "line": 64,
  "name": "To check if the user is able to buy books from javascipt category",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-buy-books-from-javascipt-category",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 63,
      "name": "@TC_07_Adding_books_from_JavaScript_Category"
    }
  ]
});
formatter.step({
  "line": 65,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 66,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 67,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 68,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 69,
  "name": "Click Shop icon",
  "keyword": "Then "
});
formatter.step({
  "line": 70,
  "name": "Click JavaScript and buy the book",
  "keyword": "And "
});
formatter.step({
  "line": 71,
  "name": "View the cart",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 3690652755,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 4202658321,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 632929296,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 1955840008,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_the_shop_icon()"
});
formatter.result({
  "duration": 7680161288,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Buying_JS_book()"
});
formatter.result({
  "duration": 7508000187,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.viewing_cart()"
});
formatter.result({
  "duration": 1546305407,
  "status": "passed"
});
formatter.scenario({
  "line": 74,
  "name": "To check if the user is able to buy books from Selenium category",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-buy-books-from-selenium-category",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 73,
      "name": "@TC_08_Adding_books_from_Selenium_Category"
    }
  ]
});
formatter.step({
  "line": 75,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 76,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 77,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 78,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 79,
  "name": "Click Shop icon",
  "keyword": "Then "
});
formatter.step({
  "line": 80,
  "name": "Click Selenium and buy the book",
  "keyword": "And "
});
formatter.step({
  "line": 81,
  "name": "View the cart",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 4118421122,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 4524752326,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 1326456198,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 2505564789,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_the_shop_icon()"
});
formatter.result({
  "duration": 6427664155,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Buying_Selenium_book()"
});
formatter.result({
  "duration": 7451464599,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.viewing_cart()"
});
formatter.result({
  "duration": 12958359984,
  "error_message": "org.openqa.selenium.WebDriverException: java.net.ConnectException: Failed to connect to localhost/0:0:0:0:0:0:0:1:33130\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027DESKTOP-P3S8U0P\u0027, ip: \u0027192.168.0.112\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_161\u0027\nDriver info: driver.version: RemoteWebDriver\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:92)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat com.pages.Register_and_Login.viewing_cart(Register_and_Login.java:102)\r\n\tat com.steps.Training_steps.viewing_cart(Training_steps.java:67)\r\n\tat ✽.Then View the cart(src/main/resources/Feature/training.feature:81)\r\nCaused by: java.net.ConnectException: Failed to connect to localhost/0:0:0:0:0:0:0:1:33130\r\n\tat okhttp3.internal.connection.RealConnection.connectSocket(RealConnection.java:247)\r\n\tat okhttp3.internal.connection.RealConnection.connect(RealConnection.java:165)\r\n\tat okhttp3.internal.connection.StreamAllocation.findConnection(StreamAllocation.java:257)\r\n\tat okhttp3.internal.connection.StreamAllocation.findHealthyConnection(StreamAllocation.java:135)\r\n\tat okhttp3.internal.connection.StreamAllocation.newStream(StreamAllocation.java:114)\r\n\tat okhttp3.internal.connection.ConnectInterceptor.intercept(ConnectInterceptor.java:42)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:121)\r\n\tat okhttp3.internal.cache.CacheInterceptor.intercept(CacheInterceptor.java:93)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:121)\r\n\tat okhttp3.internal.http.BridgeInterceptor.intercept(BridgeInterceptor.java:93)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RetryAndFollowUpInterceptor.intercept(RetryAndFollowUpInterceptor.java:126)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:147)\r\n\tat okhttp3.internal.http.RealInterceptorChain.proceed(RealInterceptorChain.java:121)\r\n\tat okhttp3.RealCall.getResponseWithInterceptorChain(RealCall.java:200)\r\n\tat okhttp3.RealCall.execute(RealCall.java:77)\r\n\tat org.openqa.selenium.remote.internal.OkHttpClient.execute(OkHttpClient.java:103)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:155)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:285)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.click(RemoteWebElement.java:84)\r\n\tat com.pages.Register_and_Login.viewing_cart(Register_and_Login.java:102)\r\n\tat com.steps.Training_steps.viewing_cart(Training_steps.java:67)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:37)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:13)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:31)\r\n\tat cucumber.runtime.java.JavaStepDefinition.execute(JavaStepDefinition.java:37)\r\n\tat cucumber.runtime.StepDefinitionMatch.runStep(StepDefinitionMatch.java:37)\r\n\tat cucumber.runtime.Runtime.runStep(Runtime.java:299)\r\n\tat cucumber.runtime.model.StepContainer.runStep(StepContainer.java:44)\r\n\tat cucumber.runtime.model.StepContainer.runSteps(StepContainer.java:39)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:44)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:91)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:93)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:37)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:98)\r\n\tat org.eclipse.jdt.internal.junit4.runner.JUnit4TestReference.run(JUnit4TestReference.java:89)\r\n\tat org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:41)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:542)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:770)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:464)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:210)\r\nCaused by: java.net.ConnectException: Connection refused: connect\r\n\tat java.net.DualStackPlainSocketImpl.waitForConnect(Native Method)\r\n\tat java.net.DualStackPlainSocketImpl.socketConnect(Unknown Source)\r\n\tat java.net.AbstractPlainSocketImpl.doConnect(Unknown Source)\r\n\tat java.net.AbstractPlainSocketImpl.connectToAddress(Unknown Source)\r\n\tat java.net.AbstractPlainSocketImpl.connect(Unknown Source)\r\n\tat java.net.PlainSocketImpl.connect(Unknown Source)\r\n\tat java.net.SocksSocketImpl.connect(Unknown Source)\r\n\tat java.net.Socket.connect(Unknown Source)\r\n\tat okhttp3.internal.platform.Platform.connectSocket(Platform.java:129)\r\n\tat okhttp3.internal.connection.RealConnection.connectSocket(RealConnection.java:245)\r\n\t... 63 more\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 85,
  "name": "To check if the user is able to able to filter the prices from low to high",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-able-to-filter-the-prices-from-low-to-high",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 84,
      "name": "@TC_09_Filtering_The_Price_from_low_to_high"
    }
  ]
});
formatter.step({
  "line": 86,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 87,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 88,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 89,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 90,
  "name": "Click Shop icon",
  "keyword": "Then "
});
formatter.step({
  "line": 91,
  "name": "In Dropdown select the prices from low to high",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 4925980899,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 6834298556,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 621342467,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 3133505108,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_the_shop_icon()"
});
formatter.result({
  "duration": 6609396936,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.low_to_high()"
});
formatter.result({
  "duration": 3105876747,
  "status": "passed"
});
formatter.scenario({
  "line": 95,
  "name": "To check if the user is able to able to filter the prices from high to low",
  "description": "",
  "id": "testing-the-practise-automation-website;to-check-if-the-user-is-able-to-able-to-filter-the-prices-from-high-to-low",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 94,
      "name": "@TC_10_Filtering_The_Price_from_high_to_low"
    }
  ]
});
formatter.step({
  "line": 96,
  "name": "Launch the chrome browser in system",
  "keyword": "Given "
});
formatter.step({
  "line": 97,
  "name": "open the Practise automation website",
  "keyword": "Then "
});
formatter.step({
  "line": 98,
  "name": "Enter the Email and password in Login",
  "keyword": "Then "
});
formatter.step({
  "line": 99,
  "name": "Click Login Button",
  "keyword": "And "
});
formatter.step({
  "line": 100,
  "name": "Click Shop icon",
  "keyword": "Then "
});
formatter.step({
  "line": 101,
  "name": "In Dropdown select the prices from high to low",
  "keyword": "Then "
});
formatter.match({
  "location": "Training_steps.launching_Browser()"
});
formatter.result({
  "duration": 5241173099,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.opening_website()"
});
formatter.result({
  "duration": 6283227699,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.Logging()"
});
formatter.result({
  "duration": 2214206638,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_login()"
});
formatter.result({
  "duration": 2715132845,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.clicking_the_shop_icon()"
});
formatter.result({
  "duration": 9374778265,
  "status": "passed"
});
formatter.match({
  "location": "Training_steps.high_to_low()"
});
formatter.result({
  "duration": 7589488974,
  "status": "passed"
});
});